from tkinter import messagebox
import numpy as np
import tkinter as tk
from tkinter import ttk
import MySQLdb
from tkinter import colorchooser
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
from tkinter import simpledialog
from pathlib import Path
from tkinter import  filedialog
import pandas as pd
import xlrd
class tkinterApp(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)
        container.pack(  fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
        self.frames = {}
        for F in (StartPage, Page1, Page3,Page2):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
            frame.configure(bg='#ffffff')
        self.show_frame(StartPage)
    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()
#                                         ******************  lOG IN PAGE  **********************
class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        global p_log,p_sign,p_background,vphoto,hphoto
        l_user = tk.Label(self,bg='#ffffff', text="Enter Username", fg="#824007", font=("Comic Sans MS", 18)).place(x=700, y=170)
        l_password = tk.Label(self, bg='#ffffff',text="Enter Password", fg="#824007", font=("Comic Sans MS", 18)).place(x=700, y=270)

        e_password = tk.Entry(self, width=30, relief="raised", borderwidth=2,show='*',
                              font=("Berlin Sans FB", 16))
        e_password.place(x=700, y=320)
        e_user = tk.Entry(self, width=30, relief="raised", borderwidth=2,
                          font=("Berlin Sans FB", 16))
        e_user.place(x=700, y=220)
        def verify():
            flag=0
            conn = MySQLdb.connect(host='localhost', database='db', user='root', password='password')
            cursor = conn.cursor()
            cursor.execute('select * from db.user')
            row = cursor.fetchone()
            username=e_user.get()
            password=e_password.get()
            while row is not None:
                veruser=row[1]
                verpass=row[2]
                if veruser==username and verpass==password:
                    flag=1
                row = cursor.fetchone()
            cursor.close()
            conn.close()
            if flag==1:
                controller.show_frame(Page2)
                conn1 = MySQLdb.connect(host='localhost', database='db', user='root', password='password')
                cursor1 = conn1.cursor()
                cursor1.execute("select email from db.user where username='" + username + "'")
                result = cursor1.fetchone()
                veremail = result[0]
                global lbl1
                lbl1 = veremail
                cursor1.close()
                conn1.close()
            else:
                ll = tk.Label(self,bg='#ffffff', text="Invalid Username or Password.",fg="#c4ab1d", font=("Comic Sans MS", 17))
                ll.place(x=750, y=440)
        p_log = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\log.png")
        p_sign = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\sign.png")
        signin = tk.Button(self, command=lambda: controller.show_frame(Page1),width=130, text="Sign Up", image=p_sign, fg="#0c6309", relief="groove", borderwidth=5,
                           compound=tk.LEFT, font=("Mongolian Baiti", 19)).place(x=1050, y=488)
        login = tk.Button(self, width=100,command=verify, text="Log in", image=p_log, fg="#0c6309", relief="groove", borderwidth=5,
                          compound=tk.LEFT, font=("Mongolian Baiti", 19)).place(x=835, y=380)
        l = tk.Label(self,bg='#ffffff', text="If you do not have an account, ", fg="#824007", font=("Comic Sans MS", 18)).place(
            x=695,
            y=493)
        p_background = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\analy.png")
        l = tk.Label(self, bg='#ffffff',height=400, width=400, image=p_background).place(x=180, y=80)
        vphoto = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\vline.png")
        hphoto = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\hline.png")
        l_v1 = tk.Label(self, height=400, width=10, image=vphoto).place(x=636, y=130)
        l_v2 = tk.Label(self, height=400, width=10, image=vphoto).place(x=1255, y=140)
        l_h1 = tk.Label(self, image=hphoto, height=20, width=590).place(x=655, y=100)
        l_h2 = tk.Label(self, image=hphoto, height=20, width=590).place(x=655, y=548 )

        name = tk.Label(self,bg='#ffffff', text="ChartsOnTheGo", fg="#5c0f2d", font=("Poor Richard", 30)).place(x=263, y=450)
#                                         ******************  SIGN IN PAGE  **********************
class Page1(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        global sp_add, sp_ohline, sp_ovline
        sl_sign = tk.Label(self, bg='#ffffff', text="Sign In", fg="#1785cf", font=("Franklin Gothic Demi", 26)).place(
            x=600, y=80)
        sl_user = tk.Label(self, bg='#ffffff', text="Enter Username", fg="#8a1d60", font=("Comic Sans MS", 18)).place(
            x=220, y=170)
        sl_password = tk.Label(self, bg='#ffffff', text="Enter Password", fg="#8a1d60",
                               font=("Comic Sans MS", 18)).place(x=220, y=350)
        sl_email = tk.Label(self, bg='#ffffff', text="Enter E-mail address", fg="#8a1d60",
                            font=("Comic Sans MS", 18)).place(x=780,
                                                              y=170)
        sl_confirm = tk.Label(self, bg='#ffffff', text="Confirm Password", fg="#8a1d60",
                              font=("Comic Sans MS", 18)).place(x=780, y=350)

        se_user = tk.Entry(self, width=25, relief="raised", borderwidth=2,
                           font=("Berlin Sans FB", 16))
        se_user.place(x=220, y=230)
        se_password = tk.Entry(self, width=25, relief="raised", borderwidth=2, show='*',
                               font=("Berlin Sans FB", 16))
        se_password.place(x=220, y=410)
        se_email = tk.Entry(self, width=25, relief="raised", borderwidth=2,
                            font=("Berlin Sans FB", 16))
        se_email.place(x=780, y=230)
        se_confirm = tk.Entry(self, width=25, relief="raised", borderwidth=2, show='*',
                              font=("Berlin Sans FB", 16))
        se_confirm.place(x=780, y=410)
        sp_add = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\add.png")
        sp_ohline = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\ohline.png")
        sp_ovline = tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\ovline.png")
        sl_hline1 = tk.Label(self, bg='#ffffff', image=sp_ohline).place(x=110, y=25)
        sl_vline1 = tk.Label(self, bg='#ffffff', image=sp_ovline).place(x=95, y=45)
        sl_hline2 = tk.Label(self, bg='#ffffff', image=sp_ohline).place(x=110, y=630)
        sl_vline2 = tk.Label(self, bg='#ffffff', image=sp_ovline).place(x=1215, y=45)
        def create():
            confirm = se_confirm.get()
            password = se_password.get()
            if confirm == password:
                name = se_user.get()
                email = se_email.get()
                conn = MySQLdb.connect(host='localhost', database='db', user='root', password='password')
                cursor = conn.cursor()
                str = "insert into user(username,password,email) values('" + name + "','" + password + "','" + email + "') "
                try:
                    cursor.execute(str)
                    conn.commit()
                    controller.show_frame(StartPage)
                except:
                    conn.rollback()
                cursor.close()
                conn.close()
            else:
                ll = tk.Label(self, bg='#ffffff', text="Password does not match.Please Re-Enter",
                              font=("Comic Sans MS", 18))
                ll.place(x=450, y=470)
        ssignin = tk.Button(self, command=create, width=230, text="Create Account", image=sp_add, fg="#0c6309",
                            relief="groove",
                            borderwidth=5,
                            compound=tk.LEFT, font=("Georgia", 18)).place(x=550, y=530)

class Page3(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        global ph
        l11=tk.Label(self,text="Enter Password",font="Georgia, 18").place(x=300,y=150)
        passwo=tk.Entry(self, width=25,  relief="raised", borderwidth=2,
                        font=("Georgia", 16),show='*')
        passwo.place(x=750,y=150)
        l1=tk.Label(self,text="Enter Reciever's email address",font="Georgia, 18").place(x=300,y=250)
        erec=tk.Entry(self, width=25,  relief="raised", borderwidth=2,
                        font=("Georgia", 16))
        erec.place(x=750,y=250)
        def send():
            from reportlab.lib.colors import blue
            from reportlab.lib.pagesizes import LETTER
            from reportlab.lib.units import inch
            from reportlab.pdfgen.canvas import Canvas
            canvas = Canvas("pyth.pdf", pagesize=LETTER)
            canvas.setFont("Times-Roman", 12)
            t = canvas.beginText()
            t.setFont("Times-Roman", 10)
            t.setCharSpace(3)
            t.setTextOrigin(30, 400)
            from textwrap import wrap
            text=str(cont)
            wraped_text = "\n".join(wrap(text, 80))  # 80 is line width
            t.textLines(wraped_text)
            canvas.drawText(t)
            canvas.drawImage(r'C:\Users\admin\Desktop\new.png',1,430,height=360,width=650)
            # Save the PDF file
            canvas.save()
            print("INSIDE",cont)
            rec = erec.get()
            passw = passwo.get()
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
            from email.mime.base import MIMEBase
            from email import encoders
            import smtplib
            body ="Thank you for using ChartsOnTheGo"
            sender = lbl1
            password = passw
            receiver = rec
            # Setup the MIME
            message = MIMEMultipart()
            message['From'] = sender
            message['To'] = receiver
            message['Subject'] = 'Email from ChartsOnTheGo'
            message.attach(MIMEText(body, 'plain'))
            pdfname =r"C:\Users\admin\Desktop\Python_proj\PYCHARM\pyth.pdf"
            binary_pdf = open(pdfname, 'rb')
            payload = MIMEBase('application', 'octate-stream', Name=pdfname)
            payload.set_payload((binary_pdf).read())
            encoders.encode_base64(payload)
            payload.add_header('Content-Decomposition', 'attachment', filename=pdfname)
            message.attach(payload)
            session = smtplib.SMTP('smtp.gmail.com', 587)
            session.starttls()
            session.login(sender, password)
            text = message.as_string()
            session.sendmail(sender, receiver, text)
            session.quit()
            print('Mail Sent')
            controller.show_frame(Page2)
        b=tk.Button(self,text="Send Mail",font="Georgia,19",command=send)
        b.config(width=15)
        b.place(x=560,y=370)
        ph= tk.PhotoImage(file=r"C:\Users\admin\Desktop\Python_proj\PYCHARM\share.png")
        sl_hline12 = tk.Label(self, bg='#ffffff', image=ph).place(x=30, y=500)
        l11=tk.Label(self,text="Thank you for using ChartsOnTheGo",font="Georgia, 22",fg='#53045c').place(x=850,y=630)

class Page2(tk.Frame):
    def __init__(self, parent, controller):
        import matplotlib.pyplot as plt
        tk.Frame.__init__(self, parent)
        la=tk.Label(self,text="Enter values separated by commas",font="Georgia, 13")
        l=tk.Label(self,text="Enter number of Variables",font="Georgia, 13")
        l1=tk.Label(self,text="Enter number of Lines to be plotted",font="Georgia, 13")
        l2=tk.Label(self,text="Enter number of Plots",font="Georgia, 13")
        l3=tk.Label(self,text="Enter number of Wedges",font="Georgia, 13")
        l4=tk.Label(self,text="Select type of Graph",font="Georgia, 13").place(x=20,y=20)
        lbb=tk.Label(self,text="Select Input Format",font="Georgia, 13")
#Color
        ctemp = tk.Entry(self, font="Georgia,12")
        etemp = tk.Entry(self, font="Georgia,12")
        ctemp2 = tk.Entry(self, font="Georgia,12")
        etemp2 = tk.Entry(self, font="Georgia,12")
        ctemp3 = tk.Entry(self, font="Georgia,12")
        etemp3 = tk.Entry(self, font="Georgia,12")
        ctemp4 = tk.Entry(self, font="Georgia,12")
        ctemp5 = tk.Entry(self, font="Georgia,12")
        ctemp6 = tk.Entry(self, font="Georgia,12")
        def cchoose_color():
            ctemp.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp.insert(0,color_code[1])
        def echoose_color():
            etemp.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose EdgeColor")
            etemp.insert(0,color_code[1])
        def cchoose_color2():
            ctemp2.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp2.insert(0,color_code[1])
        def echoose_color2():
            etemp2.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose EdgeColor")
            etemp2.insert(0,color_code[1])
        def cchoose_color3():
            ctemp3.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp3.insert(0,color_code[1])
        def cchoose_color4():
            ctemp4.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp4.insert(0,color_code[1])
        def cchoose_color5():
            ctemp5.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp5.insert(0,color_code[1])
        def cchoose_color6():
            ctemp6.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose color")
            ctemp6.insert(0, color_code[1])
        def echoose_color3():
            etemp3.delete(0, 7)
            color_code = colorchooser.askcolor(title="Choose EdgeColor")
            etemp3.insert(0,color_code[1])
        bcolor=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color)
        ecolor = tk.Button(self,text="Choose EdgeColor", font="Georgia,12", command=echoose_color)
        bcolor2=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color2)
        ecolor2 = tk.Button(self,text="Choose EdgeColor", font="Georgia,12", command=echoose_color2)
        bcolor3=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color3)
        bcolor4=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color4)
        bcolor5=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color5)
        bcolor6=tk.Button(self,text="Choose Color",font="Georgia,12",command=cchoose_color6)
        ecolor3 = tk.Button(self,text="Choose EdgeColor", font="Georgia,12", command=echoose_color3)
        xentry = tk.Entry(self, font="Georgia,12")
        yentry = tk.Entry(self, font="Georgia,12")
        tentry = tk.Entry(self, font="Georgia,12")
        sentry = tk.Entry(self, font="Georgia,12")
        tentry = tk.Entry(self, font="Georgia,12")
        combo1 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo1['values'] = ('Bar Graph', 'Line Graph', 'Scatter Plot', 'Pie Chart', 'Histogram')
        combo1.place(x=215, y=22)
        combo = ttk.Combobox(self,state="readonly",  width=27,font="Georgia, 13")
        one = tk.Entry(self,font="Georgia, 12")
        two = tk.Entry(self,font="Georgia, 12")
        three = tk.Entry(self,font="Georgia, 12")
        four = tk.Entry(self,font="Georgia, 12")
        five = tk.Entry(self,font="Georgia, 12")
        six = tk.Entry(self,font="Georgia, 12")
        seven = tk.Entry(self,font="Georgia, 12")
        eight = tk.Entry(self,font="Georgia, 12")
        nine = tk.Entry(self,font="Georgia, 12")
        ten = tk.Entry(self,font="Georgia, 12")
        eleven = tk.Entry(self,font="Georgia, 12")
        twelve = tk.Entry(self,font="Georgia, 12")
        thirteen = tk.Entry(self,font="Georgia, 12")
        fourteen = tk.Entry(self,font="Georgia, 12")
        combo2 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo2['values'] = ('solid', 'dashed', 'dotted', 'dashdot')
        combo3 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo3['values'] = ('Circle', 'Star', 'Square', 'Diamond','Triangle','No Marker')
        combo4 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo4['values'] = ('solid', 'dashed', 'dotted', 'dashdot')
        combo5 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo5['values'] = ('Circle', 'Star', 'Square', 'Diamond','Triangle','No Marker')
        combo6 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo6['values'] = ('solid', 'dashed', 'dotted', 'dashdot')
        combo7 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo7['values'] = ('Circle', 'Star', 'Square', 'Diamond','Triangle','No Marker')
        combo9 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo9['values'] = ('Circle', 'Star', 'Square', 'Diamond', 'Triangle', 'No Marker')
        combo10 = ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        combo10['values'] = ('True', 'False')
        comboinput= ttk.Combobox(self, state="readonly", width=27, font="Georgia, 13")
        comboinput['values'] = ('Mannual Entry ', 'Excel File')
        def show_chart():
            n = combo.get()
            ch=combo1.get()
            inpchoice=comboinput.get()
            global cont
            if n=="1" and ch=="Bar Graph" and inpchoice=="Excel File":
                n = list(dataframe1.columns)
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                col = ctemp.get()
                ecol = etemp.get()
                fig = plt.figure()
                ax = fig.add_subplot(111)
                cont=""
                cone = str(dataframe1[n[0]].tolist())
                l = []
                l.append(cone)
                cont = "\n     ".join(l)
                ax.bar(dataframe1[n[0]].tolist(), dataframe1[n[1]].tolist(), color=col, edgecolor=ecol, linewidth=2)
                ax.set_xlabel(xlab)
                ax.set_ylabel(ylab)
                ax.set_title(titl)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="2" and ch=="Bar Graph" and inpchoice=="Excel File":
                col1 = ctemp.get()
                ecol1 = etemp.get()
                col2 = ctemp2.get()
                ecol2 = etemp2.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                n = list(dataframe2.columns)
                x = np.arange(len(dataframe2[n[1]].tolist()))
                width = 0.35
                fig, ax = plt.subplots()
                ax.bar(x - width / 2, dataframe2[n[1]].tolist(), width, label=n[1], color=col1, edgecolor=ecol1)
                ax.bar(x + width / 2, dataframe2[n[2]].tolist(), width, label=n[2], color=col2, edgecolor=ecol2)
                cont = ""
                cone = str(dataframe2[n[0]].tolist())
                ctwo = str(dataframe2[n[1]].tolist())
                l = []
                l.append(cone)
                l.append(ctwo)
                cont = "\n     ".join(l)
                ax.set_ylabel(ylab)
                ax.set_title(titl)
                ax.set_xlabel(xlab)
                ax.set_xticks(x)
                ax.set_xticklabels(dataframe2[n[0]].tolist())
                ax.legend()
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="3" and ch=="Bar Graph" and inpchoice=="Excel File":
                col1 = ctemp.get()
                ecol1 = etemp.get()
                col2 = ctemp2.get()
                ecol2 = etemp2.get()
                col3 = ctemp3.get()
                ecol3 = etemp3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                n = list(dataframe3.columns)
                barWidth = 0.25
                fig = plt.subplots(figsize=(12, 8))
                cont = ""
                cone=str(dataframe3[n[0]].tolist())
                ctwo=str(dataframe3[n[1]].tolist())
                cthr=str(dataframe3[n[2]].tolist())
                l=[]
                l.append(cone)
                l.append(ctwo)
                l.append(cthr)
                cont="\n     ".join(l)
                br1 = np.arange(len(dataframe3[n[0]].tolist()))
                br2 = [x + barWidth for x in br1]
                br3 = [x + barWidth for x in br2]
                plt.bar(br1, dataframe3[n[1]].tolist(), label=n[1] ,color=col1,edgecolor=ecol1)
                plt.bar(br2, dataframe3[n[2]].tolist(), label=n[2],color=col2,edgecolor=ecol2)
                plt.bar(br3, dataframe3[n[3]].tolist(), label=n[3],color=col3,edgecolor=ecol3)

                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.xticks([r + barWidth for r in range(len(dataframe3[n[0]].tolist()))],
                           dataframe3[n[0]].tolist())
                plt.legend()
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="1" and ch=="Line Graph" and inpchoice=="Excel File":
                col = ctemp.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style = combo2.get()
                m = combo3.get()
                if m=="Diamond":
                    mark='D'
                elif m=="Triangle":
                    mark='^'
                elif m=="Star":
                    mark='*'
                elif m=="Square":
                    mark='s'
                elif m=="Circle":
                    mark='o'
                elif m=="No Marker":
                    mark=''
                n = list(dataframe4.columns)
                data = np.genfromtxt(dataframe4[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data['x'], data['y'],marker=mark,color=col,linestyle=style,label=n[0])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cone=str(dataframe4[n[0]].tolist())
                l=[]
                l.append(cone)
                cont="\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif n=="2" and ch=="Line Graph" and inpchoice=="Excel File":
                col1 = ctemp.get()
                col2 = ctemp2.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style1 = combo2.get()
                m1 = combo3.get()
                style2 = combo4.get()
                m2 = combo5.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                if m2 == "Diamond":
                    mark2 = 'D'
                elif m2 == "Triangle":
                    mark2 = '^'
                elif m2 == "Star":
                    mark2 = '*'
                elif m2 == "Square":
                    mark2 = 's'
                elif m2 == "Circle":
                    mark2 = 'o'
                elif m2 == "No Marker":
                    mark2 = ''
                n = list(dataframe5.columns)
                data = np.genfromtxt(dataframe5[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data['x'], data['y'], marker=mark1, color=col1, linestyle=style1, label=n[0])
                data1 = np.genfromtxt(dataframe5[n[1]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data1['x'], data1['y'], marker=mark2, color=col2, linestyle=style2, label=n[1])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cone=str(dataframe5[n[0]].tolist())
                ctwo=str(dataframe5[n[1]].tolist())
                l=[]
                l.append(cone)
                l.append(ctwo)
                cont="\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="3" and ch=="Line Graph" and inpchoice=="Excel File":
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style1 = combo2.get()
                m1 = combo3.get()
                style2 = combo4.get()
                m2 = combo5.get()
                style3 = combo6.get()
                m3 = combo7.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                if m2 == "Diamond":
                    mark2 = 'D'
                elif m2 == "Triangle":
                    mark2 = '^'
                elif m2 == "Star":
                    mark2 = '*'
                elif m2 == "Square":
                    mark2 = 's'
                elif m2 == "Circle":
                    mark2 = 'o'
                elif m2 == "No Marker":
                    mark2 = ''
                if m3 == "Diamond":
                    mark3 = 'D'
                elif m3 == "Triangle":
                    mark3 = '^'
                elif m3 == "Star":
                    mark3 = '*'
                elif m3 == "Square":
                    mark3 = 's'
                elif m3 == "Circle":
                    mark3 = 'o'
                elif m3 == "No Marker":
                    mark3 = ''
                n = list(dataframe6.columns)
                data = np.genfromtxt(dataframe6[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data['x'], data['y'], marker=mark1, color=col1, linestyle=style1, label=n[0])
                data2 = np.genfromtxt(dataframe6[n[1]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data2['x'], data2['y'], marker=mark2, color=col2, linestyle=style2, label=n[1])
                data3 = np.genfromtxt(dataframe6[n[2]].tolist(), delimiter=",", names=["x", "y"])
                plt.plot(data3['x'], data3['y'], marker=mark3, color=col3, linestyle=style3, label=n[2])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cone=str(dataframe6[n[0]].tolist())
                ctwo=str(dataframe6[n[1]].tolist())
                cthr=str(dataframe6[n[2]].tolist())
                l=[]
                l.append(cone)
                l.append(ctwo)
                l.append(cthr)
                cont="\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="1" and ch=="Scatter Plot" and inpchoice=="Excel File":
                col1 = ctemp.get()
                m1 = combo3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                n = list(dataframe7.columns)
                data = np.genfromtxt(dataframe7[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data['x'], data['y'], marker=mark1, color=col1, label=n[0])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cone=str(dataframe7[n[0]].tolist())
                l=[]
                l.append(cone)
                cont="\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "2" and ch == "Scatter Plot" and inpchoice == "Excel File":
                col1 = ctemp.get()
                col2 = ctemp2.get()
                m1 = combo3.get()
                m2 = combo5.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                if m2 == "Diamond":
                    mark2 = 'D'
                elif m2 == "Triangle":
                    mark2 = '^'
                elif m2 == "Star":
                    mark2 = '*'
                elif m2 == "Square":
                    mark2 = 's'
                elif m2 == "Circle":
                    mark2 = 'o'
                elif m2 == "No Marker":
                    mark2 = ''
                n = list(dataframe8.columns)
                data = np.genfromtxt(dataframe8[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data['x'], data['y'], marker=mark1, color=col1, label=n[0])
                data2 = np.genfromtxt(dataframe8[n[1]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data2['x'], data2['y'], marker=mark2, color=col2, label=n[1])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cone = str(dataframe8[n[0]].tolist())
                ctwo = str(dataframe8[n[1]].tolist())
                l = []
                l.append(cone)
                l.append(ctwo)
                cont="\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "3" and ch == "Scatter Plot" and inpchoice == "Excel File":
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                m1 = combo3.get()
                m2 = combo5.get()
                m3 = combo7.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                if m2 == "Diamond":
                    mark2 = 'D'
                elif m2 == "Triangle":
                    mark2 = '^'
                elif m2 == "Star":
                    mark2 = '*'
                elif m2 == "Square":
                    mark2 = 's'
                elif m2 == "Circle":
                    mark2 = 'o'
                elif m2 == "No Marker":
                    mark2 = ''
                if m3 == "Diamond":
                    mark3 = 'D'
                elif m3 == "Triangle":
                    mark3 = '^'
                elif m3 == "Star":
                    mark3 = '*'
                elif m3 == "Square":
                    mark3 = 's'
                elif m3 == "Circle":
                    mark3 = 'o'
                elif m3 == "No Marker":
                    mark3 = ''
                n = list(dataframe9.columns)
                data = np.genfromtxt(dataframe9[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data['x'], data['y'], marker=mark1, color=col1, label=n[0])
                data2 = np.genfromtxt(dataframe9[n[1]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data2['x'], data2['y'], marker=mark2, color=col2, label=n[1])
                data3 = np.genfromtxt(dataframe9[n[2]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data3['x'], data3['y'], marker=mark3, color=col3, label=n[2])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cone = str(dataframe9[n[0]].tolist())
                ctwo = str(dataframe9[n[1]].tolist())
                cthr = str(dataframe9[n[2]].tolist())
                l = []
                l.append(cone)
                l.append(ctwo)
                l.append(cthr)
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "4" and ch == "Scatter Plot" and inpchoice == "Excel File":
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                col4 = ctemp4.get()
                m1 = combo3.get()
                m2 = combo5.get()
                m3 = combo7.get()
                m4 = combo9.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                if m1 == "Diamond":
                    mark1 = 'D'
                elif m1 == "Triangle":
                    mark1 = '^'
                elif m1 == "Star":
                    mark1 = '*'
                elif m1 == "Square":
                    mark1 = 's'
                elif m1 == "Circle":
                    mark1 = 'o'
                elif m1 == "No Marker":
                    mark1 = ''
                if m2 == "Diamond":
                    mark2 = 'D'
                elif m2 == "Triangle":
                    mark2 = '^'
                elif m2 == "Star":
                    mark2 = '*'
                elif m2 == "Square":
                    mark2 = 's'
                elif m2 == "Circle":
                    mark2 = 'o'
                elif m2 == "No Marker":
                    mark2 = ''
                if m3 == "Diamond":
                    mark3 = 'D'
                elif m3 == "Triangle":
                    mark3 = '^'
                elif m3 == "Star":
                    mark3 = '*'
                elif m3 == "Square":
                    mark3 = 's'
                elif m3 == "Circle":
                    mark3 = 'o'
                elif m3 == "No Marker":
                    mark3 = ''
                if m4 == "Diamond":
                    mark4 = 'D'
                elif m4 == "Triangle":
                    mark4 = '^'
                elif m4 == "Star":
                    mark4 = '*'
                elif m4 == "Square":
                    mark4 = 's'
                elif m4 == "Circle":
                    mark4 = 'o'
                elif m4 == "No Marker":
                    mark4 = ''
                n = list(dataframe10.columns)
                data = np.genfromtxt(dataframe10[n[0]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data['x'], data['y'], marker=mark1, color=col1, label=n[0])
                data2 = np.genfromtxt(dataframe10[n[1]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data2['x'], data2['y'], marker=mark2, color=col2, label=n[1])
                data3 = np.genfromtxt(dataframe10[n[2]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data3['x'], data3['y'], marker=mark3, color=col3, label=n[2])
                data4 = np.genfromtxt(dataframe10[n[3]].tolist(), delimiter=",", names=["x", "y"])
                plt.scatter(data4['x'], data4['y'], marker=mark4, color=col4, label=n[3])
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont=""
                cone = str(dataframe10[n[0]].tolist())
                ctwo = str(dataframe10[n[1]].tolist())
                cthr = str(dataframe10[n[2]].tolist())
                cfour = str(dataframe10[n[3]].tolist())
                l = []
                l.append(cone)
                l.append(ctwo)
                l.append(cthr)
                l.append(cfour)
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif ch == "Histogram" and inpchoice == "Excel File":
                col1 = ctemp.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                n = list(dataframe11.columns)
                plt.hist(dataframe11[n[0]].tolist(), bins="auto", histtype="bar", color=col1)
                plt.title(titl)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                cont = ""
                cone = str(dataframe11[n[0]].tolist())
                l = []
                l.append(cone)
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="1" and ch=="Bar Graph":
                col=ctemp.get()
                ecol=etemp.get()
                xlab=xentry.get()
                ylab=yentry.get()
                titl=tentry.get()
                hor=one.get()
                ver=two.get()
                horizon = hor.split(",")
                ver_list = ver.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                fig = plt.figure()
                ax = fig.add_subplot(111)
                ax.bar(horizon, verizon, color=col, edgecolor=ecol, linewidth=2)
                ax.set_xlabel(xlab)
                ax.set_ylabel(ylab)
                ax.set_title(titl)
                cont = ""
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="2" and ch=="Bar Graph":
                onename=one.get()
                oneval=two.get()
                twoname=three.get()
                twoval=four.get()
                col1=ctemp.get()
                ecol1=etemp.get()
                col2=ctemp2.get()
                ecol2=etemp2.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                hor=seven.get()
                horizon = hor.split(",")
                ver_list = oneval.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = twoval.split(",")
                map_object = map(int, ver_list)
                verizon1 = list(map_object)
                x = np.arange(len(horizon))
                width = 0.35
                fig, ax = plt.subplots()
                rects1 = ax.bar(x - width / 2, verizon, width, label=onename,color=col1,edgecolor=ecol1)
                rects2 = ax.bar(x + width / 2, verizon1, width, label=twoname,color=col2,edgecolor=ecol2)
                ax.set_ylabel(ylab)
                ax.set_title(titl)
                ax.set_xlabel(xlab)
                ax.set_xticks(x)
                ax.set_xticklabels(horizon)
                ax.legend()
                cont = ""
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(verizon1))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="3" and ch=="Bar Graph":
                onename=one.get()
                oneval=two.get()
                twoname=three.get()
                twoval=four.get()
                threename=five.get()
                threeval=six.get()
                col1=ctemp.get()
                ecol1=etemp.get()
                col2=ctemp2.get()
                ecol2=etemp2.get()
                col3=ctemp3.get()
                ecol3=etemp3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                hor=seven.get()
                horizon = hor.split(",")
                ver_list = oneval.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = twoval.split(",")
                map_object = map(int, ver_list)
                verizon1 = list(map_object)
                ver_list = threeval.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                barWidth = 0.25
                fig = plt.subplots(figsize=(12, 8))
                br1 = np.arange(len(verizon))
                br2 = [x + barWidth for x in br1]
                br3 = [x + barWidth for x in br2]
                plt.bar(br1, verizon, color=col1, width=barWidth,
                        edgecolor=ecol1, label=onename)
                plt.bar(br2, verizon1, color=col2, width=barWidth,
                        edgecolor=ecol2, label=twoname)
                plt.bar(br3, verizon2, color=col3, width=barWidth,
                        edgecolor=ecol3, label=threename)
                plt.xlabel(xlab, fontsize=15)
                plt.ylabel(ylab, fontsize=15)
                plt.title(titl, fontweight='bold')
                plt.xticks([r + barWidth for r in range(len(verizon))],
                           horizon)
                plt.legend()
                cont = ""
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(verizon1))
                l.append(str(verizon2))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="1" and ch=="Line Graph":
                oneval=one.get()
                twoval=two.get()
                threeval=three.get()
                col=ctemp.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style=combo2.get()
                m=combo3.get()
                ver_list = oneval.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = twoval.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                if m=="Diamond":
                    mark='D'
                elif m=="Triangle":
                    mark='^'
                elif m=="Star":
                    mark='*'
                elif m=="Square":
                    mark='s'
                elif m=="Circle":
                    mark='o'
                elif m=="No Marker":
                    mark=''
                plt.plot(verizon,horizon,marker=mark,color=col,linestyle=style,label=threeval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                cont = "x-coordinates:", horizon,"      y-coordinates:", verizon
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n=="2" and ch=="Line Graph":
                oneval=one.get()
                twoval=two.get()
                threeval=three.get()
                fourval=four.get()
                fiveval=five.get()
                sixval=six.get()
                ver_list = oneval.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = twoval.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                ver_list = threeval.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                ver_list = fourval.split(",")
                map_object = map(int, ver_list)
                horizon2 = list(map_object)
                col1=ctemp.get()
                col2=ctemp2.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style1=combo2.get()
                m1=combo3.get()
                style2 = combo4.get()
                m2 = combo5.get()
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                if m2=="Diamond":
                    mark2='D'
                elif m2=="Triangle":
                    mark2='^'
                elif m2=="Star":
                    mark2='*'
                elif m2=="Square":
                    mark2='s'
                elif m2=="Circle":
                    mark2='o'
                elif m2=="No Marker":
                    mark2=''
                plt.plot(verizon,horizon,marker=mark1,color=col1,linestyle=style1,label=fiveval)
                plt.plot(verizon2,horizon2,marker=mark2,color=col2,linestyle=style2,label=sixval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont=""
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(horizon2))
                l.append(str(verizon2))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "3" and ch == "Line Graph":
                oneval=one.get()
                twoval=two.get()
                threeval=three.get()
                fourval=four.get()
                fiveval=five.get()
                sixval=six.get()
                sevenval = seven.get()
                eightval = eight.get()
                nineval = nine.get()
                ver_list = twoval.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = threeval.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                ver_list = fiveval.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                ver_list = sixval.split(",")
                map_object = map(int, ver_list)
                horizon2 = list(map_object)
                ver_list = eightval.split(",")
                map_object = map(int, ver_list)
                verizon3 = list(map_object)
                ver_list = nineval.split(",")
                map_object = map(int, ver_list)
                horizon3 = list(map_object)
                col1=ctemp.get()
                col2=ctemp2.get()
                col3=ctemp3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                style1=combo2.get()
                m1=combo3.get()
                style2 = combo4.get()
                m2 = combo5.get()
                style3 = combo6.get()
                m3 = combo7.get()
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                if m2=="Diamond":
                    mark2='D'
                elif m2=="Triangle":
                    mark2='^'
                elif m2=="Star":
                    mark2='*'
                elif m2=="Square":
                    mark2='s'
                elif m2=="Circle":
                    mark2='o'
                elif m2=="No Marker":
                    mark2=''
                if m3=="Diamond":
                    mark3='D'
                elif m3=="Triangle":
                    mark3='^'
                elif m3=="Star":
                    mark3='*'
                elif m3=="Square":
                    mark3='s'
                elif m3=="Circle":
                    mark3='o'
                elif m3=="No Marker":
                    mark3=''
                plt.plot(verizon,horizon,marker=mark1,color=col1,linestyle=style1,label=oneval)
                plt.plot(verizon2,horizon2,marker=mark2,color=col2,linestyle=style2,label=fourval)
                plt.plot(verizon3,horizon3,marker=mark3,color=col3,linestyle=style3,label=sevenval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont = ""
                l = []
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(horizon2))
                l.append(str(verizon2))
                l.append(str(horizon3))
                l.append(str(verizon3))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "1" and ch == "Scatter Plot":
                oneval = one.get()
                onex = two.get()
                oney = three.get()
                col1 = ctemp.get()
                m1=combo3.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                ver_list = onex.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = oney.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                plt.scatter(verizon, horizon, marker=mark1, color=col1, label=oneval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                cont=""
                l=[]
                l.append(str(horizon))
                l.append(str(verizon))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "2" and ch == "Scatter Plot":
                oneval = one.get()
                onex = two.get()
                oney = three.get()
                twoval = four.get()
                twox = five.get()
                twoy = six.get()
                col1 = ctemp.get()
                col2 = ctemp2.get()
                m1=combo3.get()
                m2=combo5.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                ver_list = onex.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = oney.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                ver_list = twox.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                ver_list = twoy.split(",")
                map_object = map(int, ver_list)
                horizon2 = list(map_object)
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                if m2=="Diamond":
                    mark2='D'
                elif m2=="Triangle":
                    mark2='^'
                elif m2=="Star":
                    mark2='*'
                elif m2=="Square":
                    mark2='s'
                elif m2=="Circle":
                    mark2='o'
                elif m2=="No Marker":
                    mark2=''
                plt.scatter(verizon, horizon, marker=mark1, color=col1,  label=oneval)
                plt.scatter(verizon2, horizon2, marker=mark2, color=col2,  label=twoval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                l=[]
                cont = ""
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(horizon2))
                l.append(str(verizon2))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "3" and ch == "Scatter Plot":
                oneval = one.get()
                onex = two.get()
                oney = three.get()
                twoval = four.get()
                twox = five.get()
                twoy = six.get()
                threeval = seven.get()
                threex = eight.get()
                threey = nine.get()
                col1=ctemp.get()
                col2=ctemp2.get()
                col3=ctemp3.get()
                m1=combo3.get()
                m2=combo5.get()
                m3=combo7.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                ver_list = onex.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = oney.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                ver_list = twox.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                ver_list = twoy.split(",")
                map_object = map(int, ver_list)
                horizon2 = list(map_object)
                ver_list = threex.split(",")
                map_object = map(int, ver_list)
                verizon3 = list(map_object)
                ver_list = threey.split(",")
                map_object = map(int, ver_list)
                horizon3 = list(map_object)
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                if m2=="Diamond":
                    mark2='D'
                elif m2=="Triangle":
                    mark2='^'
                elif m2=="Star":
                    mark2='*'
                elif m2=="Square":
                    mark2='s'
                elif m2=="Circle":
                    mark2='o'
                elif m2=="No Marker":
                    mark2=''
                if m3=="Diamond":
                    mark3='D'
                elif m3=="Triangle":
                    mark3='^'
                elif m3=="Star":
                    mark3='*'
                elif m3=="Square":
                    mark3='s'
                elif m3=="Circle":
                    mark3='o'
                elif m3=="No Marker":
                    mark3=''
                plt.scatter(verizon, horizon, marker=mark1, color=col1,  label=oneval)
                plt.scatter(verizon2, horizon2, marker=mark2, color=col2,  label=twoval)
                plt.scatter(verizon3, horizon3, marker=mark3, color=col3,  label=threeval)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()
                l=[]
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(horizon2))
                l.append(str(verizon2))
                l.append(str(horizon3))
                l.append(str(verizon3))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

            elif n == "4" and ch == "Scatter Plot":
                oneval=one.get()
                onex=two.get()
                oney=three.get()
                twoval =four.get()
                twox = five.get()
                twoy = six.get()
                threeval = seven.get()
                threex = eight.get()
                threey = nine.get()
                fourval = ten.get()
                fourx = eleven.get()
                foury = twelve.get()
                col1=ctemp.get()
                col2=ctemp2.get()
                col3=ctemp3.get()
                col4=ctemp4.get()
                m1=combo3.get()
                m2=combo5.get()
                m3=combo7.get()
                m4=combo9.get()
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                ver_list = onex.split(",")
                map_object = map(int, ver_list)
                verizon = list(map_object)
                ver_list = oney.split(",")
                map_object = map(int, ver_list)
                horizon = list(map_object)
                ver_list = twox.split(",")
                map_object = map(int, ver_list)
                verizon2 = list(map_object)
                ver_list = twoy.split(",")
                map_object = map(int, ver_list)
                horizon2 = list(map_object)
                ver_list = threex.split(",")
                map_object = map(int, ver_list)
                verizon3 = list(map_object)
                ver_list = threey.split(",")
                map_object = map(int, ver_list)
                horizon3 = list(map_object)
                ver_list = fourx.split(",")
                map_object = map(int, ver_list)
                verizon4 = list(map_object)
                ver_list = foury.split(",")
                map_object = map(int, ver_list)
                horizon4 = list(map_object)
                if m1=="Diamond":
                    mark1='D'
                elif m1=="Triangle":
                    mark1='^'
                elif m1=="Star":
                    mark1='*'
                elif m1=="Square":
                    mark1='s'
                elif m1=="Circle":
                    mark1='o'
                elif m1=="No Marker":
                    mark1=''
                if m2=="Diamond":
                    mark2='D'
                elif m2=="Triangle":
                    mark2='^'
                elif m2=="Star":
                    mark2='*'
                elif m2=="Square":
                    mark2='s'
                elif m2=="Circle":
                    mark2='o'
                elif m2=="No Marker":
                    mark2=''
                if m3=="Diamond":
                    mark3='D'
                elif m3=="Triangle":
                    mark3='^'
                elif m3=="Star":
                    mark3='*'
                elif m3=="Square":
                    mark3='s'
                elif m3=="Circle":
                    mark3='o'
                elif m3=="No Marker":
                    mark3=''
                if m4=="Diamond":
                    mark4='D'
                elif m4=="Triangle":
                    mark4='^'
                elif m4=="Star":
                    mark4='*'
                elif m4=="Square":
                    mark4='s'
                elif m4=="Circle":
                    mark4='o'
                elif m4=="No Marker":
                    mark4=''
                plt.scatter(verizon, horizon, marker=mark1, color=col1,  label=oneval)
                plt.scatter(verizon2, horizon2, marker=mark2, color=col2,  label=twoval)
                plt.scatter(verizon3, horizon3, marker=mark3, color=col3,  label=threeval)
                plt.scatter(verizon4, horizon4, marker=mark4, color=col4, label=fourval)
                l=[]
                l.append(str(horizon))
                l.append(str(verizon))
                l.append(str(horizon2))
                l.append(str(verizon2))
                l.append(str(horizon3))
                l.append(str(verizon3))
                l.append(str(horizon4))
                l.append(str(verizon4))
                cont = "\n     ".join(l)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                plt.title(titl)
                plt.legend()

                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif n == "2" and ch == "Pie Chart":
                onename = one.get()
                oneval = two.get()
                twoname = three.get()
                twoval = four.get()
                col1 = ctemp.get()
                col2 = ctemp2.get()
                shado = combo10.get()
                angle = five.get()
                lc = [col1, col2]
                li = [onename, twoname]
                lj = [int(oneval), int(twoval)]
                data = np.array(lj)
                labe = np.array(li)
                cosl = np.array(lc)
                if shado == "False":
                    plt.pie(data, labels=labe, shadow=False, colors=cosl, startangle=int(angle))
                else:
                    plt.pie(data, labels=labe, shadow=True, colors=cosl, startangle=int(angle))
                cont = ""
                l = []
                l.append(str(lj))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.legend()
                plt.show()
            elif n == "3" and ch == "Pie Chart":
                onename = one.get()
                oneval = two.get()
                twoname = three.get()
                twoval = four.get()
                threename = five.get()
                threeval = six.get()
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                shado = combo10.get()
                angle = seven.get()
                lc = [col1, col2, col3]
                li = [onename, twoname, threename]
                lj = [int(oneval), int(twoval), int(threeval)]
                data = np.array(lj)
                labe = np.array(li)
                cosl = np.array(lc)
                if shado == "False":
                    plt.pie(data, labels=labe, shadow=False, colors=cosl, startangle=int(angle))
                else:
                    plt.pie(data, labels=labe, shadow=True, colors=cosl, startangle=int(angle))
                plt.legend()
                cont = ""
                l = []
                l.append(str(lj))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif n == "4" and ch == "Pie Chart":
                onename = one.get()
                oneval = two.get()
                twoname = three.get()
                twoval = four.get()
                threename = five.get()
                threeval = six.get()
                fourname = seven.get()
                fourval = eight.get()
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                col4 = ctemp4.get()
                shado = combo10.get()
                angle = nine.get()
                lc = [col1, col2, col3, col4]
                li = [onename, twoname, threename, fourname]
                lj = [int(oneval), int(twoval), int(threeval), int(fourval)]
                data = np.array(lj)
                labe = np.array(li)
                cosl = np.array(lc)
                if shado == "False":
                    plt.pie(data, labels=labe, shadow=False, colors=cosl, startangle=int(angle))
                else:
                    plt.pie(data, labels=labe, shadow=True, colors=cosl, startangle=int(angle))

                plt.legend()
                cont=""
                l = []
                l.append(str(lj))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif n == "5" and ch == "Pie Chart":
                onename = one.get()
                oneval = two.get()
                twoname = three.get()
                twoval = four.get()
                threename = five.get()
                threeval = six.get()
                fourname = seven.get()
                fourval = eight.get()
                fivename = nine.get()
                fiveval = ten.get()
                col1 = ctemp.get()
                col2 = ctemp2.get()
                col3 = ctemp3.get()
                col4 = ctemp4.get()
                col5 = ctemp5.get()
                shado = combo10.get()
                angle = eleven.get()
                lc = [col1, col2, col3, col4, col5]
                li = [onename, twoname, threename, fourname, fivename]
                lj = [int(oneval), int(twoval), int(threeval), int(fourval), int(fiveval)]
                data = np.array(lj)
                labe = np.array(li)
                cosl = np.array(lc)
                if shado=="False":
                    plt.pie(data, labels=labe, shadow=False, colors=cosl, startangle=int(angle))
                else:
                    plt.pie(data, labels=labe, shadow=True, colors=cosl, startangle=int(angle))

                plt.legend()
                cont = ""
                l = []
                l.append(str(lj))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif n == "6" and ch == "Pie Chart":
                onename=one.get()
                oneval = two.get()
                twoname = three.get()
                twoval = four.get()
                threename = five.get()
                threeval = six.get()
                fourname = seven.get()
                fourval = eight.get()
                fivename = nine.get()
                fiveval = ten.get()
                sixname = eleven.get()
                sixval = twelve.get()
                col1=ctemp.get()
                col2=ctemp2.get()
                col3=ctemp3.get()
                col4=ctemp4.get()
                col5=ctemp5.get()
                col6=ctemp6.get()
                shado=combo10.get()
                angle=thirteen.get()
                lc=[col1,col2,col3,col4,col5,col6]
                li=[onename,twoname,threename,fourname,fivename,sixname]
                lj=[int(oneval),int(twoval),int(threeval),int(fourval),int(fiveval),int(sixval)]
                data=np.array(lj)
                labe=np.array(li)
                cosl=np.array(lc)
                plt.pie(data, labels=labe,shadow=shado,colors = cosl,startangle=int(angle))
                plt.legend()
                cont = ""
                l = []
                l.append(str(lj))
                cont = "\n     ".join(l)
                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()
            elif  ch == "Histogram":
                oneval = two.get()
                col1 = ctemp.get()
                ver_list = oneval.split(",")
                map_object = map(int, ver_list)
                tverizon = list(map_object)
                verizon=np.array(tverizon)
                xlab = xentry.get()
                ylab = yentry.get()
                titl = tentry.get()
                plt.hist(verizon,bins="auto",histtype="bar",color=col1)
                plt.title(titl)
                plt.xlabel(xlab)
                plt.ylabel(ylab)
                cont = "Dataset:", verizon.tolist()
                l = []
                l.append(str(verizon))
                cont = "\n     ".join(l)

                plt.savefig(r'C:\Users\admin\Desktop\new.png')
                plt.show()

        showchart = tk.Button(self,text="Show Chart", font="Georgia,12",command=show_chart)
        sharechart = tk.Button(self,text="Share Chart", font="Georgia,12",command=lambda:controller.show_frame(Page3))

        def confirm():
            ch = combo1.get()
            inpchoice=comboinput.get()
            gen,g=0,0
            print("OPT",inpchoice)
            if ch!="Histogram":
                gen = combo.get()
                g = int(gen)
            if g == 1 and ch == "Bar Graph" and inpchoice=="Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                print(filname)
                global dataframe1
                dataframe1 = pd.read_excel(Path(filname))
                print(Path(filname))
                print(dataframe1)
                lcolor = tk.Label(self, text="Select color", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor", font="Georgia, 13").place(x=750, y=80)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=140)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=200)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=260)
                xentry.place(x=1000, y=140)
                yentry.place(x=1000, y=200)
                tentry.place(x=1000, y=260)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                showchart.place(x=840, y=350)
                sharechart.place(x=980, y=350)

            elif g == 2 and ch == "Bar Graph" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                         filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe2
                dataframe2 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Variable 1", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor for Variable 1", font="Georgia, 13").place(x=750, y=80)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                lcolor2 = tk.Label(self, text="Select Color for Variable 2", font="Georgia, 13").place(x=750, y=150)
                ledge2 = tk.Label(self, text="Select Edgecolor for Variable 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=148)
                ecolor2.place(x=1000, y=208)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=270)
                xentry.place(x=1000, y=268)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=330)
                yentry.place(x=1000, y=328)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=390)
                tentry.place(x=1000, y=388)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g == 3 and ch == "Bar Graph" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe3
                dataframe3 = pd.read_excel(Path(filname))

                lcolor = tk.Label(self, text="Select Color for Variable 1", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor for Variable 1", font="Georgia, 13").place(x=750, y=80)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                lcolor2 = tk.Label(self, text="Select Color for Variable 2", font="Georgia, 13").place(x=750, y=150)
                ledge2 = tk.Label(self, text="Select Edgecolor for Variable 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=148)
                ecolor2.place(x=1000, y=208)
                lcolor3 = tk.Label(self, text="Select Color for Variable 3", font="Georgia, 13").place(x=750, y=280)
                ledge3 = tk.Label(self, text="Select Edgecolor for Variable 3", font="Georgia, 13").place(x=750, y=340)
                bcolor3.place(x=1000, y=278)
                ecolor3.place(x=1000, y=338)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=400)
                xentry.place(x=1000, y=400)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=460)
                yentry.place(x=1000, y=460)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=520)
                tentry.place(x=1000, y=520)
                showchart.place(x=840, y=580)
                sharechart.place(x=980, y=580)

            elif g == 1 and ch == "Line Graph" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe4
                dataframe4 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Plot", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Line Style for Plot", font="Georgia, 13").place(x=750, y=80)
                combo2.place(x=1000, y=80)
                tk.Label(self, text="Select Marker for Plot", font="Georgia, 13").place(x=750, y=140)
                combo3.place(x=1000, y=140)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=200)
                xentry.place(x=1000, y=200)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=260)
                yentry.place(x=1000, y=260)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=320)
                tentry.place(x=1000, y=320)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g == 2 and ch == "Line Graph" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe5
                dataframe5 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Line Style for Line 1", font="Georgia, 13").place(x=750, y=80)
                combo2.place(x=1000, y=78)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=140)
                combo3.place(x=1000, y=138)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=208)
                tk.Label(self, text="Select Line Style for Line 2", font="Georgia, 13").place(x=750, y=270)
                combo4.place(x=1000, y=268)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=330)
                combo5.place(x=1000, y=328)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=390)
                xentry.place(x=1000, y=390)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=450)
                yentry.place(x=1000, y=450)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=510)
                tentry.place(x=1000, y=510)
                showchart.place(x=840, y=580)
                sharechart.place(x=980, y=580)

            elif g == 3 and ch == "Line Graph" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe6
                dataframe6 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Line Style for Line 1", font="Georgia, 13").place(x=750, y=75)
                combo2.place(x=1000, y=73)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=125)
                combo3.place(x=1000, y=123)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=180)
                bcolor2.place(x=1000, y=173)
                tk.Label(self, text="Select Line Style for Line 2", font="Georgia, 13").place(x=750, y=240)
                combo4.place(x=1000, y=237)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=290)
                combo5.place(x=1000, y=287)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=345)
                bcolor3.place(x=1000, y=343)
                tk.Label(self, text="Select Line Style for Line 3", font="Georgia, 13").place(x=750, y=405)
                combo6.place(x=1000, y=403)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=455)
                combo7.place(x=1000, y=453)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=500)
                xentry.place(x=1000, y=497)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=550)
                yentry.place(x=1000, y=547)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=600)
                tentry.place(x=1000, y=597)
                showchart.place(x=840, y=640)
                sharechart.place(x=980, y=640)

            elif g == 1 and ch == "Scatter Plot" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe7
                dataframe7 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Plot", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=80)
                combo3.place(x=1000, y=80)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=150)
                xentry.place(x=1000, y=148)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=210)
                yentry.place(x=1000, y=208)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=270)
                tentry.place(x=1000, y=268)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g == 2 and ch == "Scatter Plot" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe8
                dataframe8 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=95)
                combo3.place(x=1000, y=93)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=160)
                bcolor2.place(x=1000, y=157)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=230)
                combo5.place(x=1000, y=228)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=300)
                xentry.place(x=1000, y=298)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=360)
                yentry.place(x=1000, y=358)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=420)
                tentry.place(x=1000, y=408)
                showchart.place(x=840, y=500)
                sharechart.place(x=980, y=500)

            elif g == 3 and ch == "Scatter Plot" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe9
                dataframe9 = pd.read_excel(Path(filname))
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=75)
                combo3.place(x=1000, y=75)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=130)
                bcolor2.place(x=1000, y=130)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=185)
                combo5.place(x=1000, y=185)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=240)
                bcolor3.place(x=1000, y=240)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=295)
                combo7.place(x=1000, y=295)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=350)
                xentry.place(x=1000, y=350)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=405)
                yentry.place(x=1000, y=405)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=460)
                tentry.place(x=1000, y=460)
                showchart.place(x=840, y=530)
                sharechart.place(x=980, y=530)

            elif g == 4 and ch == "Scatter Plot" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe10
                dataframe10 = pd.read_excel(Path(filname))
                tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=75)
                combo3.place(x=1000, y=75)
                lcolor = tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=130)
                bcolor2.place(x=1000, y=130)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=185)
                combo5.place(x=1000, y=185)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=240)
                bcolor3.place(x=1000, y=240)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=295)
                combo7.place(x=1000, y=295)
                tk.Label(self, text="Select Color for Line 4", font="Georgia, 13").place(x=750, y=350)
                bcolor4.place(x=1000, y=350)
                tk.Label(self, text="Select Marker for Line 4", font="Georgia, 13").place(x=750, y=405)
                combo9.place(x=1000, y=405)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=460)
                xentry.place(x=1000, y=460)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=530)
                yentry.place(x=1000, y=530)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=585)
                tentry.place(x=1000, y=585)
                showchart.place(x=840, y=640)
                sharechart.place(x=980, y=640)

            elif ch == "Histogram" and inpchoice == "Excel File":
                filname = filedialog.askopenfilename(initialdir="/", title='Select the Excel File',
                                                     filetypes=(("excel files", "*.xls"), ("all files", "*.*")))
                global dataframe11
                dataframe11 = pd.read_excel(Path(filname))
                tk.Label(self, text="Select Color", font="Georgia, 13").place(x=750, y=50)
                bcolor.place(x=1000, y=50)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=130)
                xentry.place(x=1000, y=130)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=210)
                yentry.place(x=1000, y=210)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=290)
                tentry.place(x=1000, y=290)
                showchart.place(x=840, y=415)
                sharechart.place(x=980, y=415)

            elif ch == "Histogram" :
                lm = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=195)
                two.place(x=50, y=235, height=30, width=600)
                tk.Label(self, text="Select Color", font="Georgia, 13").place(x=750, y=50)
                bcolor.place(x=1000, y=50)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=130)
                xentry.place(x=1000, y=130)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=210)
                yentry.place(x=1000, y=210)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=290)
                tentry.place(x=1000, y=290)
                showchart.place(x=840, y=415)
                sharechart.place(x=980, y=415)

            elif g == 1 and ch=="Bar Graph":
                l.place(x=20, y=75)
                lk = tk.Label(self, text="Enter Labels to be represented on x-axis", font="Georgia, 12")
                lm = tk.Label(self, text="Enter data values", font="Georgia, 12")
                one.place(x=50, y=240, height=30, width=600)
                two.place(x=50, y=330, height=30, width=600)
                lk.place(x=50,y=195)
                lm.place(x=50,y=300)
                xentry.place(x=1000, y=140)
                yentry.place(x=1000, y=200)
                tentry.place(x=1000, y=260)
                lcolor = tk.Label(self, text="Select color", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor", font="Georgia, 13").place(x=750, y=80)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=140)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=200)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=260)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                showchart.place(x=840, y=350)
                sharechart.place(x=980, y=350)

            elif g == 2 and ch=="Bar Graph":
                l.place(x=20, y=75)
                lk = tk.Label(self, text="Enter Name of variable 1", font="Georgia, 12").place(x=50, y=195)
                one.place(x=250, y=195, height=30, width=200)
                lm = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=233)
                two.place(x=50, y=263, height=30, width=600)
                lk1 = tk.Label(self, text="Enter Name of variable 2", font="Georgia, 12").place(x=50, y=327)
                three.place(x=250, y=327, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=365)
                four.place(x=50, y=395, height=30, width=600)

                lk = tk.Label(self, text="Enter Labels to be represented on x-axis", font="Georgia, 12").place(x=50,
                                                                                                               y=457)
                seven.place(x=50, y=490, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Variable 1", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor for Variable 1", font="Georgia, 13").place(x=750, y=80)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                lcolor2 = tk.Label(self, text="Select Color for Variable 2", font="Georgia, 13").place(x=750, y=150)
                ledge2 = tk.Label(self, text="Select Edgecolor for Variable 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=148)
                ecolor2.place(x=1000, y=208)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=270)
                xentry.place(x=1000, y=268)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=330)
                yentry.place(x=1000, y=328)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=390)
                tentry.place(x=1000, y=388)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g == 3 and ch=="Bar Graph":
                l.place(x=20, y=75)
                lk = tk.Label(self, text="Enter Name of variable 1", font="Georgia, 12").place(x=50, y=195)
                one.place(x=250, y=195, height=30, width=200)
                lm = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=233)
                two.place(x=50, y=263, height=30, width=600)
                lk1 = tk.Label(self, text="Enter Name of variable 2", font="Georgia, 12").place(x=50, y=327)
                three.place(x=250, y=327, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=365)
                four.place(x=50, y=395, height=30, width=600)
                lk2 = tk.Label(self, text="Enter Name of variable 3", font="Georgia, 12").place(x=50, y=457)
                five.place(x=250, y=457, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data values", font="Georgia, 12").place(x=50, y=495)
                six.place(x=50, y=525, height=30, width=600)
                lk = tk.Label(self, text="Enter Labels to be represented on x-axis", font="Georgia, 12").place(x=50,
                                                                                                               y=570)
                seven.place(x=50, y=600, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Variable 1", font="Georgia, 13").place(x=750, y=20)
                ledge = tk.Label(self, text="Select Edgecolor for Variable 1", font="Georgia, 13").place(x=750, y=80)
                bcolor.place(x=1000, y=20)
                ecolor.place(x=1000, y=70)
                lcolor2 = tk.Label(self, text="Select Color for Variable 2", font="Georgia, 13").place(x=750, y=150)
                ledge2 = tk.Label(self, text="Select Edgecolor for Variable 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=148)
                ecolor2.place(x=1000, y=208)
                lcolor3 = tk.Label(self, text="Select Color for Variable 3", font="Georgia, 13").place(x=750, y=280)
                ledge3 = tk.Label(self, text="Select Edgecolor for Variable 3", font="Georgia, 13").place(x=750, y=340)
                bcolor3.place(x=1000, y=278)
                ecolor3.place(x=1000, y=338)
                lx = tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=400)
                xentry.place(x=1000, y=400)
                ly = tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=460)
                yentry.place(x=1000, y=460)
                ltitle = tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=520)
                tentry.place(x=1000, y=520)
                showchart.place(x=840, y=580)
                sharechart.place(x=980, y=580)

            elif g == 1 and ch=="Line Graph":
                tk.Label(self,text="Enter Name for Plot", font="Georgia, 12").place(x=50, y=175)
                three.place(x=250, y=173, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x)", font="Georgia, 12").place(x=50,y=240)
                one.place(x=50, y=280, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y)", font="Georgia, 12").place(x=50, y=370)
                two.place(x=50, y=410, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Plot", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Line Style for Plot", font="Georgia, 13").place(x=750, y=80)
                combo2.place(x=1000, y=80)
                tk.Label(self, text="Select Marker for Plot", font="Georgia, 13").place(x=750, y=140)
                combo3.place(x=1000, y=140)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=200)
                xentry.place(x=1000, y=200)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=260)
                yentry.place(x=1000, y=260)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=320)
                tentry.place(x=1000, y=320)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g == 2 and ch=="Line Graph":
                tk.Label(self,text="Enter Name for Line 1", font="Georgia, 12").place(x=50, y=175)
                five.place(x=250, y=173, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 1", font="Georgia, 12").place(x=50,y=220)
                one.place(x=50, y=260, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 1", font="Georgia, 12").place(x=50, y=305)
                two.place(x=50, y=340, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 2", font="Georgia, 12").place(x=50, y=405)
                six.place(x=250, y=403, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 2", font="Georgia, 12").place(x=50,y=450)
                three.place(x=50, y=485, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 2", font="Georgia, 12").place(x=50, y=525)
                four.place(x=50, y=560, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Line Style for Line 1", font="Georgia, 13").place(x=750, y=80)
                combo2.place(x=1000,y=78)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=140)
                combo3.place(x=1000,y=138)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=210)
                bcolor2.place(x=1000, y=208)
                tk.Label(self, text="Select Line Style for Line 2", font="Georgia, 13").place(x=750, y=270)
                combo4.place(x=1000,y=268)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=330)
                combo5.place(x=1000,y=328)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=390)
                xentry.place(x=1000, y=390)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=450)
                yentry.place(x=1000, y=450)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=510)
                tentry.place(x=1000, y=510)
                showchart.place(x=840, y=580)
                sharechart.place(x=980, y=580)

            elif g == 3 and ch == "Line Graph":
                tk.Label(self,text="Enter Name for Line 1", font="Georgia, 12").place(x=50, y=165)
                one.place(x=250, y=162, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 1", font="Georgia, 12").place(x=50,y=200)
                two.place(x=50, y=230, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 1", font="Georgia, 12").place(x=50, y=268)
                three.place(x=50, y=295, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 2", font="Georgia, 12").place(x=50, y=340)
                four.place(x=250, y=337, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 2", font="Georgia, 12").place(x=50,y=372)
                five.place(x=50, y=407, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 2", font="Georgia, 12").place(x=50, y=442)
                six.place(x=50, y=470, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 3", font="Georgia, 12").place(x=50, y=515)
                seven.place(x=250, y=513, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 3", font="Georgia, 12").place(x=50, y=545)
                eight.place(x=50, y=570, height=30, width=600)
                tk.Label(self,text="Enter data for x-axis (x) for Line 3", font="Georgia, 12").place(x=50, y=600)
                nine.place(x=50, y=625, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Line Style for Line 1", font="Georgia, 13").place(x=750, y=75)
                combo2.place(x=1000,y=73)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=125)
                combo3.place(x=1000,y=123)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=180)
                bcolor2.place(x=1000, y=173)
                tk.Label(self, text="Select Line Style for Line 2", font="Georgia, 13").place(x=750, y=240)
                combo4.place(x=1000,y=237)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=290)
                combo5.place(x=1000,y=287)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=345)
                bcolor3.place(x=1000, y=343)
                tk.Label(self, text="Select Line Style for Line 3", font="Georgia, 13").place(x=750, y=405)
                combo6.place(x=1000, y=403)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=455)
                combo7.place(x=1000, y=453)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=500)
                xentry.place(x=1000, y=497)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=550)
                yentry.place(x=1000, y=547)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=600)
                tentry.place(x=1000, y=597)
                showchart.place(x=840, y=640)
                sharechart.place(x=980, y=640)

            elif g==1 and ch=="Scatter Plot":
                tk.Label(text="Enter Name for Plot", font="Georgia, 12").place(x=50, y=175)
                one.place(x=250, y=173, height=30, width=200)
                tk.Label(text="Enter data for x-axis (x)", font="Georgia, 12").place(x=50, y=240)
                two.place(x=50, y=280, height=30, width=600)
                tk.Label(text="Enter data for y-axis (y)", font="Georgia, 12").place(x=50, y=370)
                three.place(x=50, y=410, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Plot", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=20)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=80)
                combo3.place(x=1000, y=80)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=150)
                xentry.place(x=1000, y=148)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=210)
                yentry.place(x=1000, y=208)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=270)
                tentry.place(x=1000, y=268)
                showchart.place(x=840, y=450)
                sharechart.place(x=980, y=450)

            elif g==2 and ch=="Scatter Plot":
                tk.Label(self,text="Enter Name for Line 1", font="Georgia, 12").place(x=50, y=175)
                one.place(x=250, y=173, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 1", font="Georgia, 12").place(x=50, y=220)
                two.place(x=50, y=260, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 1", font="Georgia, 12").place(x=50, y=305)
                three.place(x=50, y=340, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 2", font="Georgia, 12").place(x=50, y=405)
                four.place(x=250, y=403, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 2", font="Georgia, 12").place(x=50, y=450)
                five.place(x=50, y=485, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 2", font="Georgia, 12").place(x=50, y=525)
                six.place(x=50, y=560, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=20)
                bcolor.place(x=1000, y=18)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=95)
                combo3.place(x=1000, y=93)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=160)
                bcolor2.place(x=1000, y=157)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=230)
                combo5.place(x=1000, y=228)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=300)
                xentry.place(x=1000, y=298)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=360)
                yentry.place(x=1000, y=358)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=420)
                tentry.place(x=1000, y=408)
                showchart.place(x=840, y=500)
                sharechart.place(x=980, y=500)

            elif g == 3 and ch == "Scatter Plot":
                tk.Label(self,text="Enter Name for Line 1", font="Georgia, 12").place(x=50, y=175)
                one.place(x=250, y=173, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 1", font="Georgia, 12").place(x=50,y=220)
                two.place(x=50, y=260, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 1", font="Georgia, 12").place(x=50, y=305)
                three.place(x=50, y=340, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 2", font="Georgia, 12").place(x=50, y=405)
                four.place(x=250, y=403, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 2", font="Georgia, 12").place(x=50,y=450)
                five.place(x=50, y=485, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 2", font="Georgia, 12").place(x=50, y=525)
                six.place(x=50, y=560, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 3", font="Georgia, 12").place(x=50, y=600)
                seven.place(x=250, y=598, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 3", font="Georgia, 12").place(x=750, y=20)
                eight.place(x=750, y=50, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 32", font="Georgia, 12").place(x=750, y=85)
                nine.place(x=750, y=115, height=30, width=600)
                lcolor = tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=175)
                bcolor.place(x=1000, y=173)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=225)
                combo3.place(x=1000,y=223)
                tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=280)
                bcolor2.place(x=1000, y=277)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=335)
                combo5.place(x=1000,y=333)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=385)
                bcolor3.place(x=1000, y=383)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=435)
                combo7.place(x=1000, y=433)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=487)
                xentry.place(x=1000, y=487)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=533)
                yentry.place(x=1000, y=533)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=575)
                tentry.place(x=1000, y=573)
                showchart.place(x=840, y=625)
                sharechart.place(x=980, y=625)

            elif g == 4 and ch=="Scatter Plot":
                tk.Label(self,text="Enter Name for Line 1", font="Georgia, 12").place(x=50, y=165)
                one.place(x=250, y=162, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 1", font="Georgia, 12").place(x=50,y=200)
                two.place(x=50, y=230, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 1", font="Georgia, 12").place(x=50, y=268)
                three.place(x=50, y=295, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 2", font="Georgia, 12").place(x=50, y=340)
                four.place(x=250, y=337, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 2", font="Georgia, 12").place(x=50,y=372)
                five.place(x=50, y=407, height=30, width=600)
                tk.Label(self,text="Enter data for y-axis (y) for Line 2", font="Georgia, 12").place(x=50, y=442)
                six.place(x=50, y=470, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 3", font="Georgia, 12").place(x=50, y=515)
                seven.place(x=250, y=513, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 3", font="Georgia, 12").place(x=50, y=545)
                eight.place(x=50, y=570, height=30, width=600)
                tk.Label(self,text="Enter data for x-axis (x) for Line 3", font="Georgia, 12").place(x=50, y=600)
                nine.place(x=50, y=625, height=30, width=600)
                tk.Label(self,text="Enter Name for Line 4", font="Georgia, 12").place(x=750, y=10)
                ten.place(x=1000, y=8, height=30, width=200)
                tk.Label(self,text="Enter data for x-axis (x) for Line 4", font="Georgia, 12").place(x=750, y=43)
                eleven.place(x=750, y=70, height=30, width=600)
                tk.Label(self,text="Enter data for x-axis (x) for Line 4", font="Georgia, 12").place(x=750, y=97)
                twelve.place(x=750, y=127, height=30, width=600)
                tk.Label(self, text="Select Color for Line 1", font="Georgia, 13").place(x=750, y=160)
                bcolor.place(x=1000, y=157)
                tk.Label(self, text="Select Marker for Line 1", font="Georgia, 13").place(x=750, y=205)
                combo3.place(x=1000, y=203)
                lcolor = tk.Label(self, text="Select Color for Line 2", font="Georgia, 13").place(x=750, y=245)
                bcolor2.place(x=1000, y=243)
                tk.Label(self, text="Select Marker for Line 2", font="Georgia, 13").place(x=750, y=293)
                combo5.place(x=1000,y=293)
                tk.Label(self, text="Select Color for Line 3", font="Georgia, 13").place(x=750, y=330)
                bcolor3.place(x=1000, y=327)
                tk.Label(self, text="Select Marker for Line 3", font="Georgia, 13").place(x=750, y=379)
                combo7.place(x=1000,y=375)
                tk.Label(self, text="Select Color for Line 4", font="Georgia, 13").place(x=750, y=423)
                bcolor4.place(x=1000, y=417)
                tk.Label(self, text="Select Marker for Line 4", font="Georgia, 13").place(x=750, y=470)
                combo9.place(x=1000, y=467)
                tk.Label(self, text="Enter x-label", font="Georgia, 13").place(x=750, y=515)
                xentry.place(x=1000, y=513)
                tk.Label(self, text="Enter y-label", font="Georgia, 13").place(x=750, y=560)
                yentry.place(x=1000, y=557)
                tk.Label(self, text="Enter title", font="Georgia, 13").place(x=750, y=600)
                tentry.place(x=1000, y=597)
                showchart.place(x=840, y=640)
                sharechart.place(x=980, y=640)

            elif g == 2 and ch == "Pie Chart":
                la.place(x=170, y=147)
                lk = tk.Label(self, text="Enter Name of wedge 1", font="Georgia, 12").place(x=50, y=205)
                one.place(x=300, y=205, height=30, width=200)
                lm = tk.Label(self, text="Enter data value for wedge 1", font="Georgia, 12").place(x=50, y=280)
                two.place(x=300, y=280, height=30, width=200)
                lk1 = tk.Label(self, text="Enter Name of wedge 2", font="Georgia, 12").place(x=50, y=405)
                three.place(x=300, y=405, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 2", font="Georgia, 12").place(x=50, y=450)
                four.place(x=300, y=450, height=30, width=200)
                tk.Label(self, text="Select Color for Plot 1", font="Georgia, 13").place(x=750, y=30)
                bcolor.place(x=1000, y=30)
                tk.Label(self, text="Select Color for Plot 2", font="Georgia, 13").place(x=750, y=110)
                bcolor2.place(x=1000, y=110)
                tk.Label(self, text="Enter Start Angle", font="Georgia, 13").place(x=750, y=210)
                five.place(x=1000, y=210, height=30, width=200)
                tk.Label(self, text="Show Shadow:", font="Georgia, 13").place(x=750, y=290)
                combo10.place(x=1000, y=290)
                showchart.place(x=840, y=400)
                sharechart.place(x=980, y=400)

            elif g == 3 and ch == "Pie Chart":
                lk = tk.Label(self, text="Enter Name of wedge 1", font="Georgia, 12").place(x=50, y=205)
                one.place(x=300, y=205, height=30, width=200)
                lm = tk.Label(self, text="Enter data value for wedge 1", font="Georgia, 12").place(x=50, y=260)
                two.place(x=300, y=260, height=30, width=200)
                lk1 = tk.Label(self, text="Enter Name of wedge 2", font="Georgia, 12").place(x=50, y=345)
                three.place(x=300, y=345, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 2", font="Georgia, 12").place(x=50, y=390)
                four.place(x=300, y=390, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 3", font="Georgia, 12").place(x=50, y=475)
                five.place(x=300, y=475, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 3", font="Georgia, 12").place(x=50, y=520)
                six.place(x=300, y=520, height=30, width=200)
                tk.Label(self, text="Select Color for Plot 1", font="Georgia, 13").place(x=750, y=30)
                bcolor.place(x=1000, y=30)
                tk.Label(self, text="Select Color for Plot 2", font="Georgia, 13").place(x=750, y=110)
                bcolor2.place(x=1000, y=110)
                tk.Label(self, text="Select Color for Plot 3", font="Georgia, 13").place(x=750, y=190)
                bcolor3.place(x=1000, y=190)
                tk.Label(self, text="Enter Start Angle", font="Georgia, 13").place(x=750, y=290)
                seven.place(x=1000, y=290, height=30, width=200)
                tk.Label(self, text="Show Shadow:", font="Georgia, 13").place(x=750, y=350)
                combo10.place(x=1000, y=350)
                showchart.place(x=840, y=500)
                sharechart.place(x=980, y=500)

            elif g==4 and ch=="Pie Chart":
                la.place(x=170, y=147)
                lk = tk.Label(self, text="Enter Name of wedge 1", font="Georgia, 12").place(x=50, y=205)
                one.place(x=300, y=205, height=30, width=200)
                lm = tk.Label(self, text="Enter data value for wedge 1", font="Georgia, 12").place(x=50, y=260)
                two.place(x=300, y=260, height=30, width=200)
                lk1 = tk.Label(self, text="Enter Name of wedge 2", font="Georgia, 12").place(x=50, y=325)
                three.place(x=300, y=325, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 2", font="Georgia, 12").place(x=50, y=370)
                four.place(x=300, y=370, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 3", font="Georgia, 12").place(x=50, y=435)
                five.place(x=300, y=435, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 3", font="Georgia, 12").place(x=50, y=480)
                six.place(x=300, y=480, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 4", font="Georgia, 12").place(x=50, y=545)
                seven.place(x=300, y=545, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 4", font="Georgia, 12").place(x=50, y=590)
                eight.place(x=300, y=590, height=30, width=200)
                tk.Label(self, text="Select Color for Plot 1", font="Georgia, 13").place(x=750, y=30)
                bcolor.place(x=1000, y=30)
                tk.Label(self, text="Select Color for Plot 2", font="Georgia, 13").place(x=750, y=110)
                bcolor2.place(x=1000, y=110)
                tk.Label(self, text="Select Color for Plot 3", font="Georgia, 13").place(x=750, y=190)
                bcolor3.place(x=1000, y=190)
                tk.Label(self, text="Select Color for Plot 4", font="Georgia, 13").place(x=750, y=270)
                bcolor4.place(x=1000, y=270)
                tk.Label(self, text="Enter Start Angle", font="Georgia, 13").place(x=750, y=350)
                nine.place(x=1000, y=350, height=30, width=200)
                tk.Label(self, text="Show Shadow:", font="Georgia, 13").place(x=750, y=430)
                combo10.place(x=1000, y=430)
                showchart.place(x=840, y=530)
                sharechart.place(x=980, y=530)

            elif g==5 and ch=="Pie Chart":
                la.place(x=170, y=147)
                lk = tk.Label(self, text="Enter Name of wedge 1", font="Georgia, 12").place(x=50, y=195)
                one.place(x=300, y=195, height=30, width=200)
                lm = tk.Label(self, text="Enter data value for wedge 1", font="Georgia, 12").place(x=50, y=250)
                two.place(x=300, y=250, height=30, width=200)
                lk1 = tk.Label(self, text="Enter Name of wedge 2", font="Georgia, 12").place(x=50, y=310)
                three.place(x=300, y=310, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 2", font="Georgia, 12").place(x=50, y=355)
                four.place(x=300, y=355, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 3", font="Georgia, 12").place(x=50, y=415)
                five.place(x=300, y=415, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 3", font="Georgia, 12").place(x=50, y=460)
                six.place(x=300, y=460, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 4", font="Georgia, 12").place(x=50, y=520)
                seven.place(x=300, y=520, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 4", font="Georgia, 12").place(x=50, y=565)
                eight.place(x=300, y=565, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 5", font="Georgia, 12").place(x=750, y=20)
                nine.place(x=1000, y=20, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 5", font="Georgia, 12").place(x=750, y=80)
                ten.place(x=1000, y=80, height=30, width=200)
                tk.Label(self, text="Select Color for Plot 1", font="Georgia, 13").place(x=750, y=140)
                bcolor.place(x=1000, y=140)
                tk.Label(self, text="Select Color for Plot 2", font="Georgia, 13").place(x=750, y=200)
                bcolor2.place(x=1000, y=200)
                tk.Label(self, text="Select Color for Plot 3", font="Georgia, 13").place(x=750, y=260)
                bcolor3.place(x=1000, y=260)
                tk.Label(self, text="Select Color for Plot 4", font="Georgia, 13").place(x=750, y=320)
                bcolor4.place(x=1000, y=320)
                tk.Label(self, text="Select Color for Plot 5", font="Georgia, 13").place(x=750, y=380)
                bcolor5.place(x=1000, y=380)
                tk.Label(self, text="Enter Start Angle", font="Georgia, 13").place(x=750, y=440)
                eleven.place(x=1000, y=440, height=30, width=200)
                tk.Label(self, text="Show Shadow:", font="Georgia, 13").place(x=750, y=500)
                combo10.place(x=1000, y=500)
                showchart.place(x=840, y=560)
                sharechart.place(x=980, y=560)

            elif g==6 and ch=="Pie Chart":
                la.place(x=170, y=147)
                lk = tk.Label(self, text="Enter Name of wedge 1", font="Georgia, 12").place(x=50, y=195)
                one.place(x=300, y=195, height=30, width=200)
                lm = tk.Label(self, text="Enter data value for wedge 1", font="Georgia, 12").place(x=50, y=240)
                two.place(x=300, y=240, height=30, width=200)
                lk1 = tk.Label(self, text="Enter Name of wedge 2", font="Georgia, 12").place(x=50, y=300)
                three.place(x=300, y=300, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 2", font="Georgia, 12").place(x=50, y=345)
                four.place(x=300, y=345, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 3", font="Georgia, 12").place(x=50, y=405)
                five.place(x=300, y=405, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 3", font="Georgia, 12").place(x=50, y=450)
                six.place(x=300, y=450, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 4", font="Georgia, 12").place(x=50, y=510)
                seven.place(x=300, y=510, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 4", font="Georgia, 12").place(x=50, y=555)
                eight.place(x=300, y=555, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 5", font="Georgia, 12").place(x=50, y=615)
                nine.place(x=300, y=615, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 5", font="Georgia, 12").place(x=750, y=20)
                ten.place(x=1000, y=20, height=30, width=200)
                lk2 = tk.Label(self, text="Enter Name of wedge 6", font="Georgia, 12").place(x=750, y=80)
                eleven.place(x=1000, y=80, height=30, width=200)
                lm1 = tk.Label(self, text="Enter data value for wedge 6", font="Georgia, 12").place(x=750, y=125)
                twelve.place(x=1000, y=125, height=30, width=200)
                tk.Label(self, text="Select Color for Plot 1", font="Georgia, 13").place(x=750, y=185)
                bcolor.place(x=1000, y=185)
                tk.Label(self, text="Select Color for Plot 2", font="Georgia, 13").place(x=750, y=235)
                bcolor2.place(x=1000, y=235)
                tk.Label(self, text="Select Color for Plot 3", font="Georgia, 13").place(x=750, y=295)
                bcolor3.place(x=1000, y=295)
                tk.Label(self, text="Select Color for Plot 4", font="Georgia, 13").place(x=750, y=345)
                bcolor4.place(x=1000, y=345)
                tk.Label(self, text="Select Color for Plot 5", font="Georgia, 13").place(x=750, y=395)
                bcolor5.place(x=1000, y=395)
                tk.Label(self, text="Select Color for Plot 6", font="Georgia, 13").place(x=750, y=445)
                bcolor6.place(x=1000, y=445)
                tk.Label(self, text="Enter Start Angle", font="Georgia, 13").place(x=750, y=495)
                thirteen.place(x=1000, y=495, height=30, width=200)
                tk.Label(self, text="Show Shadow:", font="Georgia, 13").place(x=750, y=555)
                combo10.place(x=1000,y=555)
                showchart.place(x=840, y=615)
                sharechart.place(x=980, y=615)

        next=tk.Button(self,text="Confirm",command=confirm, font="Georgia, 13")

        def generate():
                ch = combo1.get()
                if ch=="Line Graph":
                    l1.place(x=20, y=75)
                    combo['values'] = ('1', '2', '3')
                    combo.place(x=297, y=75)
                    next.place(x=580, y=110)
                    lbb.place(x=20, y=115)
                    comboinput.place(x=200, y=113)

                elif ch=="Scatter Plot":
                    l2.place(x=20, y=75)
                    combo['values'] = ('1', '2', '3', '4')
                    combo.place(x=297, y=75)
                    next.place(x=580, y=110)
                    lbb.place(x=20, y=115)
                    comboinput.place(x=200, y=113)

                elif ch=="Bar Graph":
                    l.place(x=20, y=75)
                    combo['values'] = ('1', '2', '3')
                    combo.place(x=297, y=75)
                    next.place(x=580, y=110)
                    lbb.place(x=20, y=115)
                    comboinput.place(x=200, y=113)

                elif ch=="Pie Chart":
                    l3.place(x=20, y=75)
                    combo['values'] = ('2', '3', '4', '5', '6')
                    combo.place(x=297, y=75)
                    next.place(x=580, y=70)

                elif ch=="Histogram":
                    lbb.place(x=20, y=115)
                    comboinput.place(x=200, y=113)
                    next.place(x=580, y=115)

        sub = tk.Button(self, command=generate, text="Generate", font="Georgia, 12")
        sub.place(x=500,y=18)

        # Driver Code
app = tkinterApp()
app.geometry('1355x688+0+0')
app.resizable(width=0, height=0)
app.mainloop()




